<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Tạo đánh giá mới
function createReview($conn,$data) {
    $tourid = $data['tourid'];
    $userid = $data['userid'];
    $username = $data['username'];
    $reviewText = $data['reviewText'];
    $rating = $data['rating'];
  

    $sql = "INSERT INTO danhgia (tourid, userid, username, reviewText, rating) 
            VALUES ('$tourid', '$userid', '$username', '$reviewText', '$rating')";
    if ($conn->query($sql) === TRUE) {
        return ["success" => true, "message" => "Reviews is add"];
    } else {
        return ["success" => false, "message" => "Error: " . $conn->error];
    }
// Kiểm tra dữ liệu đầu vào

}

// Lấy tất cả đánh giá cho một tour
function getTourReviews($conn, $tourid) {
    // Truy vấn để lấy đánh giá
    $sql = "SELECT * FROM danhgia WHERE tourid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $tourid);
    $stmt->execute();
    
    // Lấy kết quả
    $result = $stmt->get_result();
    
    // Lấy dữ liệu đánh giá
    $reviews = $result->fetch_all(MYSQLI_ASSOC);
    
    // Trả về danh sách đánh giá
    return [
        'status' => 200,
        'data' => $reviews
    ];
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $response = createReview($conn, $data);
    echo json_encode($response);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['tourid'])) {
        $response = getTourReviews($conn, $_GET['tourid']);
    
    echo json_encode($response);
}
}