<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$tourid = isset($_GET['tourid']) ? intval($_GET['tourid']) : null;

if ($tourid == null) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid tour ID']);
    exit;
}

// Truy vấn cơ sở dữ liệu để lấy thông tin tour
$sql = "SELECT * FROM tour WHERE tourid = $tourid";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    // Lấy dữ liệu tour
    $tour = $result->fetch_assoc();

    // Trả về dữ liệu dưới dạng JSON
    header('Content-Type: application/json');
    echo json_encode($tour);
} else {
    // Nếu không tìm thấy tour
    header('HTTP/1.1 404 Not Found');
    echo json_encode(['error' => 'Tour not found']);
}

// Đóng kết nối
$conn->close();

?>