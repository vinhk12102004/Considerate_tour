<?php
require_once('./connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $diadiem = isset($_GET['tendiadiem']) ? $_GET['tendiadiem'] : null;
        $maxGroupSize = isset($_GET['gioihannguoi']) ? $_GET['gioihannguoi'] : null;
        $price = isset($_GET['giatour']) ? $_GET['giatour'] : null;

        $query = "SELECT * FROM tour WHERE 1 ";

        if ($diadiem) {
            $query .= " AND tendiadiem LIKE '%" . $diadiem . "%'";
        }

        if ($maxGroupSize) {
            $query .= " AND gioihannguoi >= " . intval($maxGroupSize);
        }

        if ($price) {
            $query .= " AND giatour <= " . intval($price);
        }

        $stmt = $dbCon->prepare($query);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $response = array(
            'success' => true,
            'count' => count($data),
            'message' => "Search results retrieved successfully",
            'data' => $data
        );

        header('Content-Type: application/json');
        echo json_encode($response);
    } catch (PDOException $e) {
        echo json_encode(array('success' => false, 'message' => $e->getMessage()));
    }
}
?>