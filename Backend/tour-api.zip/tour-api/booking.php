<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

function createBooking($conn, $data) {
    $userId = $data['userId'];
    $tourName = $data['tourName'];
    $fullName = $data['fullName'];
    $groupSize = $data['groupSize'];
    $phone = $data['phone'];
    $bookAt = $data['bookAt'];

    $sql = "INSERT INTO booking (userId, tourName, fullName, groupSize, phone, bookAt) 
            VALUES ('$userId', '$tourName', '$fullName', '$groupSize', '$phone', '$bookAt')";

    if ($conn->query($sql) === TRUE) {
        return ["success" => true, "message" => "Your Tour is Booked"];
    } else {
        return ["success" => false, "message" => "Error: " . $conn->error];
    }
}
function getAllBookings($conn) {
    $sql = "SELECT * FROM booking";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        return ["success" => true, "message" => "Bookings retrieved successfully", "data" => $bookings];
    } else {
        return ["success" => false, "message" => "Failed to get bookings"];
    }
}
function getBooking($conn, $id) {
    $sql = "SELECT * FROM booking WHERE id = '$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $booking = $result->fetch_assoc();
        return ["success" => true, "message" => "Booking retrieved successfully", "data" => $booking];
    } else {
        return ["success" => false, "message" => "Booking not found"];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $response = createBooking($conn, $data);
    echo json_encode($response);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $response = getBooking($conn, $_GET['id']);
    } else {
        $response = getAllBookings($conn);
    }
    echo json_encode($response);
}

?>