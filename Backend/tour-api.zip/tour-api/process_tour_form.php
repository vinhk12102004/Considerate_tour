<?php
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname = "tour5"; 

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$json_data = file_get_contents('php://input');

// Chuyển đổi dữ liệu JSON thành mảng PHP
$data = json_decode($json_data, true);

// Kiểm tra nếu dữ liệu đã được chuyển đổi thành công
if ($data !== null) {
    // Lấy dữ liệu từ mảng $data
    $ten = $data["ten"];
    $phone = $data["phone"];
    $email = $data["email"];
    $tentour = $data["tentour"];
    $area = $data["area"];
    $address = $data["address"];
    $gioihannguoi = $data["limit"];
    $soluongtrong = $data["unlimit"];
    $start = $data["start"];
    $end = $data["end"];
    $giatour = $data["giatour"];
    $chitiet = $data["chitiet"];
    $image = $data["image"];
    $images = $data["images"];
    $ngay1 = $data["ngay1"];
    $imagengay1 = $data["imagengay1"];
    $ndngay1 = $data["ndngay1"];
    $ngay2 = $data["ngay2"];
    $imagengay2 = $data["imagengay2"];
    $ndngay2 = $data["ndngay2"];
    $ngay3 = $data["ngay3"];
    $imagengay3 = $data["imagengay3"];
    $ndngay3 = $data["ndngay3"];
    $ngay4 = $data["ngay4"];
    $imagengay4 = $data["imagengay4"];
    $ndngay4 = $data["ndngay4"];
    $ngay5 = $data["ngay5"];
    $imagengay5 = $data["imagengay5"];
    $ndngay5 = $data["ndngay5"];
    $ngay6 = $data["ngay6"];
    $imagengay6 = $data["imagengay6"];
    $ndngay6 = $data["ndngay6"];
    $ngay7 = $data["ngay7"];
    $imagengay7 = $data["imagengay7"];
    $ndngay7 = $data["ndngay7"];
    
    // Các trường dữ liệu khác...

    // Tiếp tục xử lý dữ liệu như thông thường
    } else {
    // Xử lý trường hợp dữ liệu JSON không hợp lệ
    echo "Invalid JSON data";
    }
    $sql = "INSERT INTO tour (adminname, adminphone, mail, tentour, area, tendiadiem, gioihannguoi,soluongtrong  , thoigiandi, thoigianve, giatour, chitiet, image, images, ngay1, imagengay1, ndngay1, ngay2, imagengay2, ndngay2, ngay3, imagengay3, ndngay3, ngay4, imagengay4, ndngay4, ngay5, imagengay5, ndngay5, ngay6, imagengay6, ndngay6, ngay7, imagengay7, ndngay7) VALUES ('$ten', '$phone', '$email', '$tentour', '$area', '$address', '$gioihannguoi','$soluongtrong', '$start', '$end', '$giatour', '$chitiet', '$image', '$images', '$ngay1', '$imagengay1','$ndngay1', '$ngay2', '$imagengay2','$ndngay2', '$ngay3', '$imagengay3','$ndngay3', '$ngay4', '$imagengay4','$ndngay4', '$ngay5', '$imagengay5','$ndngay5', '$ngay6', '$imagengay6','$ndngay6','$ngay7', '$imagengay7','$ndngay7')";
    
    // if ($conn->query($sql) === TRUE) {
        $last_admin_id = $conn->insert_id;
        if ($conn->query($sql) === TRUE) { // This line executes the query again
            echo "<h1>Tour created successfully</h1>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    
    

    $conn->close();

?>